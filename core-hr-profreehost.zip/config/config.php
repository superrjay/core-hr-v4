<?php
declare(strict_types=1);

const APP_NAME = 'Core HR';
const APP_TIMEZONE = 'Asia/Manila';
date_default_timezone_set(APP_TIMEZONE);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('core_hr_session');
    session_start(['cookie_httponly' => true, 'cookie_samesite' => 'Lax', 'use_strict_mode' => true]);
}
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/ai.php';
require_once __DIR__ . '/../includes/functions.php';
foreach ([
    'GeminiService.php',
    'AIContextBuilder.php',
    'PromptBuilder.php',
    'AIOutputValidator.php',
    'EmployeeProfiler.php',
    'DocumentDraftingAI.php',
] as $aiClassFile) {
    require_once dirname(__DIR__) . '/ai/' . $aiClassFile;
}