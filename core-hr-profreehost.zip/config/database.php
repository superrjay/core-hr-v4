<?php
declare(strict_types=1);

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $host = getenv('CORE_HR_DB_HOST') ?: 'sql110.ezyro.com';
    $port = getenv('CORE_HR_DB_PORT') ?: '3306';
    $name = getenv('CORE_HR_DB_NAME') ?: 'ezyro_43021176_core_hr_1';
    $user = getenv('CORE_HR_DB_USER') ?: 'ezyro_43021176';
    $pass = getenv('CORE_HR_DB_PASS') ?: '06e03de19996c';
    $pdo = new PDO("mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4", $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
    return $pdo;
}